import mysql.connector

#START of CLASS: Database
class Database:
    #START of FUNCTION: init
    def __init__(self, host="localhost", user="root", password="", database="girlyeatz"):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
    #END of FUNCTION: init

    #START of FUNCTION: create
    def create(self):
        self.database()
        self.location()
        self.restaurant()
        self.type()
        self.promo()
        self.menu()
    #END of FUNCTION: create

    #START of FUNCTION: database
    def database(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password)
        cursor = connection.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {self.database}")
        print('Database created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: database

    #START of FUNCTION: restaurant
    def restaurant(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        cursor = connection.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS restaurant ("
            "id INT NOT NULL AUTO_INCREMENT,"
            "name VARCHAR(255) NOT NULL,"
            "location INT NOT NULL,"
            "distance DOUBLE NOT NULL,"
            "rating DOUBLE NOT NULL,"
            "link VARCHAR(255) NOT NULL,"
            "PRIMARY KEY (id),"
            "FOREIGN KEY (location) REFERENCES location(id))"
        )
        print('Restaurant table created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: restaurant

    #START of FUNCTION: menu
    def menu(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        cursor = connection.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS menu ("
            "id INT NOT NULL AUTO_INCREMENT,"
            "restaurant INT NOT NULL,"
            "name VARCHAR(255) NOT NULL,"
            "price DOUBLE NOT NULL,"
            "PRIMARY KEY (id),"
            "FOREIGN KEY (restaurant) REFERENCES restaurant(id))"
        )
        print('Menu table created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: menu

    #START of FUNCTION: location
    def location(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        cursor = connection.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS location ("
            "id INT NOT NULL AUTO_INCREMENT,"
            "building VARCHAR(255) NOT NULL,"
            "street VARCHAR(255) NOT NULL,"
            "city VARCHAR(255) NOT NULL,"
            "PRIMARY KEY (id))"
        )
        print('Location table created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: location

    #START of FUNCTION: type
    def type(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        cursor = connection.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS type ("
            "id INT NOT NULL AUTO_INCREMENT,"
            "restaurant INT NOT NULL,"
            "type VARCHAR(255) NOT NULL"
            "PRIMARY KEY (id),"
            "FOREIGN KEY (restaurant) REFERENCES restaurant(id))"
        )
        print('Type table created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: type

    #START of FUNCTION: promo
    def promo(self):
        connection = mysql.connector.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        cursor = connection.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS promo ("
            "id INT NOT NULL AUTO_INCREMENT,"
            "restaurant INT NOT NULL,"
            "name VARCHAR(255) NOT NULL,"
            "details VARCHAR(255) NOT NULL,"
            "start VARCHAR(255) NOT NULL,"
            "end VARCHAR(255) NOT NULL,"
            "PRIMARY KEY (id),"
            "FOREIGN KEY (restaurant) REFERENCES restaurant(id))"
        )
        print('Promo table created successfully')
        cursor.close()
        connection.close()
    #END of FUNCTION: promo
#END of CLASS: Database
